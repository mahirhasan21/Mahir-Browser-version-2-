# MAHIR BROWSER — Android Studio Project

এটি একটি Android WebView-ভিত্তিক ব্রাউজার প্রজেক্ট। অ্যাপের হোমপেজ, শর্টকাট, সার্চ, ট্যাব বার ও মেনু নতুন Obsidian Aurora (dark violet + cyan) UI-তে সাজানো হয়েছে।

## প্রধান ফিচার

- ওয়েবসাইট ও Google Search খোলা
- Google, YouTube, Facebook, Messenger, WhatsApp, Telegram, Instagram, X, Gmail, Maps ও Wikipedia শর্টকাট
- একাধিক ট্যাব তৈরি, বদলানো ও বন্ধ করা
- নিচ থেকে ওঠা 3-dot quick menu
- Bookmarks ও সর্বশেষ 100টি normal browsing history entry
- Android Download Manager-এ ফাইল ডাউনলোড
- Private Tab: history save করে না, WebView cache ও DOM storage বন্ধ রাখে এবং private tab খোলা থাকা অবস্থায় cookies গ্রহণ বন্ধ রাখে
- Desktop Mode
- Extension ZIP picker (প্রজেক্টের extension engine অনুযায়ী)
- Share page, refresh, clear cache/cookies
- GitHub Actions workflow দিয়ে Debug APK build

## APK বানানোর নিয়ম

1. ZIP extract করে `DragonBrowser` ফোল্ডারটি GitHub repository-তে upload করুন।
2. GitHub repository-র **Actions** tab খুলুন।
3. **Build MAHIR BROWSER APK** workflow নির্বাচন করে **Run workflow** চাপুন।
4. Build সফল হলে `MAHIR-BROWSER-debug-apk` artifact থেকে `app-debug.apk` download করুন।

অথবা Android Studio-তে `DragonBrowser` ফোল্ডারটি Open করে Gradle Sync শেষে **Build > Build APK(s)** নির্বাচন করুন।

## গুরুত্বপূর্ণ নোট

- এটি WebView browser; কিছু ওয়েবসাইট তাদের নিজস্ব অ্যাপ বা পূর্ণ Chrome browser চাইতে পারে।
- Private Tab চালু থাকলে cookie acceptance অ্যাপের সব WebView tab-এর জন্য সাময়িকভাবে বন্ধ থাকে; শেষ private tab বন্ধ হলে আবার চালু হয়। এটি আলাদা Android profile নয়।
- কিছু সাইটের camera/microphone ব্যবহার করতে Android permission চাইতে পারে।
- APK এই পরিবেশে Android SDK দিয়ে build/run করে পরীক্ষা করা যায়নি; GitHub Actions বা Android Studio-তে প্রথম build যাচাই করুন।

## নতুন লাল (Red Neon) UI

- Splash, হোম, মেনু, Bookmarks, History, Downloads, Extensions, Settings, Incognito, Tabs — সব স্ক্রিন এখন একই লাল-কালো ডিজাইনে (`assets/panel.html`, `assets/home.html`, `assets/ui.css`)।
- আগের ধূসর Android ডায়ালগ আর নেই।
- Settings-এ Ad Blocker (সহজ হোস্ট-লিস্ট ভিত্তিক), Desktop Mode, History save চালু/বন্ধ করা যায়।
- Downloads স্ক্রিন Android DownloadManager থেকে এই অ্যাপের ডাউনলোড দেখায়।
- এই পরিবেশে Android SDK না থাকায় APK build করে ফোনে চালানো যায়নি; HTML স্ক্রিনগুলো ব্রাউজারে পরীক্ষা করা হয়েছে। প্রথম build GitHub Actions/Android Studio-তে যাচাই করুন।
