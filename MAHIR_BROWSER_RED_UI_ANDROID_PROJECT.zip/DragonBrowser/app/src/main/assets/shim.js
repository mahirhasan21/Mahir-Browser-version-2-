/* Dragon Browser - mini "chrome.*" extension runtime.
 * Runs at document start in every page, extension popup and extension background page.
 * Native side (Java) object: window.__DM
 */
(function () {
  'use strict';
  if (window.__dmBooted) return;
  window.__dmBooted = true;

  var tries = 0;
  (function wait() {
    if (window.__DM) {
      try { boot(window.__DM); } catch (e) { try { console.error('[DM shim]', e); } catch (_) {} }
      return;
    }
    if (++tries < 100) setTimeout(wait, 20);
  })();

  function boot(N) {
    var kind = N.kind();
    var ORIGIN = (location.origin && location.origin !== 'null') ? location.origin : 'https://dm.ext';
    var ctxs = {};
    var cbs = {};
    var cbN = (window.top === window) ? 0 : Math.floor(Math.random() * 1e9) + 1000;

    function newCb(fn) { var id = ++cbN; cbs[id] = fn; return id; }

    window.__dmCb = function (id, json) {
      var f = cbs[id];
      if (!f) return;
      delete cbs[id];
      var v;
      try { v = (json === null || json === undefined || json === 'null') ? undefined : JSON.parse(json); } catch (e) { v = undefined; }
      f(v);
    };

    function done(cb, v) { Promise.resolve().then(function () { try { cb(v); } catch (e) { try { console.error(e); } catch (_) {} } }); }

    function withCb(cb, invoke) {
      if (typeof cb === 'function') { invoke(cb); return undefined; }
      return new Promise(function (res) { invoke(res); });
    }

    function ev(list) {
      return {
        addListener: function (f) { if (typeof f === 'function' && list.indexOf(f) < 0) list.push(f); },
        removeListener: function (f) { var i = list.indexOf(f); if (i >= 0) list.splice(i, 1); },
        hasListener: function (f) { return list.indexOf(f) >= 0; },
        hasListeners: function () { return list.length > 0; }
      };
    }
    function noev() { return ev([]); }
    function js(v) { var s = JSON.stringify(v === undefined ? null : v); return s === undefined ? 'null' : s; }

    function mk(extId) {
      var L = { msg: [], chg: [] };
      var api = {};

      function getURL(p) { return ORIGIN + '/__dm_ext__/' + extId + '/' + String(p || '').replace(/^\/+/, ''); }

      api.runtime = {
        id: extId,
        lastError: undefined,
        getURL: getURL,
        getManifest: function () { try { return JSON.parse(N.manifest(extId)); } catch (e) { return {}; } },
        sendMessage: function () {
          var a = Array.prototype.slice.call(arguments), cb = null, msg;
          if (a.length && typeof a[a.length - 1] === 'function') cb = a.pop();
          if (a.length >= 3) msg = a[1];
          else if (a.length === 2 && typeof a[0] === 'string') msg = a[1];
          else msg = a[0];
          return withCb(cb, function (f) {
            var id = newCb(f);
            try { N.send(extId, 'bg', 0, js(msg), id); } catch (e) { delete cbs[id]; f(undefined); }
          });
        },
        onMessage: ev(L.msg),
        onMessageExternal: noev(),
        onConnect: noev(),
        onInstalled: noev(),
        onStartup: noev(),
        onSuspend: noev(),
        connect: function () {
          return { name: '', postMessage: function () {}, disconnect: function () {}, onMessage: noev(), onDisconnect: noev() };
        },
        getPlatformInfo: function (cb) { return withCb(cb, function (f) { done(f, { os: 'android', arch: 'arm' }); }); },
        openOptionsPage: function () {},
        setUninstallURL: function () {},
        reload: function () {}
      };
      api.extension = { getURL: getURL };

      function area() {
        return {
          get: function (keys, cb) {
            if (typeof keys === 'function') { cb = keys; keys = null; }
            return withCb(cb, function (f) {
              var r = {};
              try { r = JSON.parse(N.storageGet(extId, js(keys))); } catch (e) {}
              done(f, r);
            });
          },
          set: function (obj, cb) {
            return withCb(cb, function (f) {
              try { N.storageSet(extId, js(obj || {})); } catch (e) {}
              done(f, undefined);
            });
          },
          remove: function (keys, cb) {
            return withCb(cb, function (f) {
              try { N.storageRemove(extId, js(keys)); } catch (e) {}
              done(f, undefined);
            });
          },
          clear: function (cb) {
            return withCb(cb, function (f) {
              try { N.storageClear(extId); } catch (e) {}
              done(f, undefined);
            });
          },
          getBytesInUse: function (k, cb) {
            if (typeof k === 'function') cb = k;
            return withCb(cb, function (f) { done(f, 0); });
          },
          onChanged: ev(L.chg)
        };
      }
      var local = area();
      api.storage = { local: local, sync: area(), session: area(), managed: area(), onChanged: ev(L.chg) };
      // sync/session/managed use the same data as local (separate listener lists are fine)
      api.storage.sync.onChanged = api.storage.onChanged;

      api.tabs = {
        query: function (q, cb) {
          if (typeof q === 'function') cb = q;
          return withCb(cb, function (f) {
            var r = [];
            try { r = JSON.parse(N.tabsQuery()); } catch (e) {}
            done(f, r);
          });
        },
        sendMessage: function (tabId, msg, opt, cb) {
          if (typeof opt === 'function') { cb = opt; opt = null; }
          return withCb(cb, function (f) {
            var id = newCb(f);
            try { N.send(extId, 'tab', tabId | 0, js(msg), id); } catch (e) { delete cbs[id]; f(undefined); }
          });
        },
        create: function (p, cb) {
          try { N.tabsCreate(String((p && p.url) || '')); } catch (e) {}
          return withCb(cb, function (f) { done(f, {}); });
        },
        get: function (id, cb) {
          return withCb(cb, function (f) {
            var r = {};
            try { var a = JSON.parse(N.tabsQuery()); r = a[0] || {}; } catch (e) {}
            done(f, r);
          });
        },
        onUpdated: noev(), onActivated: noev(), onRemoved: noev(), onCreated: noev()
      };

      var act = {
        onClicked: noev(),
        setBadgeText: function () {}, setBadgeBackgroundColor: function () {},
        setTitle: function () {}, setIcon: function () {}, setPopup: function () {},
        enable: function () {}, disable: function () {}
      };
      api.action = act; api.browserAction = act; api.pageAction = act;

      api.permissions = {
        contains: function (p, cb) { return withCb(cb, function (f) { done(f, true); }); },
        request: function (p, cb) { return withCb(cb, function (f) { done(f, true); }); },
        getAll: function (cb) { return withCb(cb, function (f) { done(f, { permissions: [], origins: [] }); }); }
      };

      api.i18n = {
        getMessage: function (k) { try { return N.i18n(extId, String(k)); } catch (e) { return ''; } },
        getUILanguage: function () { return navigator.language || 'en'; }
      };

      ctxs[extId] = { api: api, L: L };
      return ctxs[extId];
    }

    function getCtx(id) { return ctxs[id] || mk(id); }
    window.__dmApi = function (id) { return getCtx(id).api; };

    // ---- messages arriving from other contexts
    window.__dmDeliver = function (extId, msgJson, senderJson, respId) {
      var c = ctxs[extId];
      var finished = false;
      function reply(v) {
        if (finished) return;
        finished = true;
        try { N.respond(respId, v === undefined ? 'null' : JSON.stringify(v)); } catch (e) {}
      }
      if (!c) { reply(undefined); return; }
      var msg, sender;
      try { msg = JSON.parse(msgJson); } catch (e) { msg = null; }
      try { sender = JSON.parse(senderJson); } catch (e) { sender = {}; }
      var pending = false;
      c.L.msg.slice().forEach(function (fn) {
        try {
          var r = fn(msg, sender, reply);
          if (r === true) pending = true;
          else if (r && typeof r.then === 'function') { pending = true; r.then(reply, function () { reply(undefined); }); }
        } catch (e) { try { console.error(e); } catch (_) {} }
      });
      if (!pending && !finished) reply(undefined);
    };

    window.__dmChanged = function (extId, changesJson, areaName) {
      var c = ctxs[extId];
      if (!c) return;
      var ch;
      try { ch = JSON.parse(changesJson); } catch (e) { return; }
      c.L.chg.slice().forEach(function (fn) { try { fn(ch, areaName || 'local'); } catch (e) {} });
    };

    // ---- extension pages (popup / background): define chrome + browser globally
    if (kind !== 'tab') {
      var id0 = window.__DM_EXT;
      if (id0) {
        var api0 = getCtx(id0).api;
        ['chrome', 'browser'].forEach(function (k) {
          try { Object.defineProperty(window, k, { value: api0, configurable: true, writable: true, enumerable: false }); } catch (e) {}
        });
      }
      return;
    }

    // ---- normal web pages: inject content scripts
    var reg = window.__DM_REG || [];
    if (!reg.length) return;

    function esc(s) { return s.replace(/[.+?^${}()|[\]\\]/g, '\\$&'); }
    var reCache = {};
    function patToRe(p) {
      if (Object.prototype.hasOwnProperty.call(reCache, p)) return reCache[p];
      var re = null;
      if (p === '<all_urls>') {
        re = /^(?:https?|wss?|ftp|file):\/\/.*/i;
      } else {
        var m = /^(\*|https?|wss?|ftp|file):\/\/([^\/]*)(\/.*)$/i.exec(p);
        if (m) {
          var sc = m[1] === '*' ? '(?:https?|wss?)' : m[1];
          var host = m[2], hs;
          if (host === '*') hs = '[^/]*';
          else if (host.indexOf('*.') === 0) hs = '(?:[^/]+\\.)?' + esc(host.slice(2)) + '(?::\\d+)?';
          else hs = esc(host) + '(?::\\d+)?';
          try { re = new RegExp('^' + sc + ':\\/\\/' + hs + esc(m[3]).replace(/\*/g, '.*') + '$', 'i'); } catch (e) { re = null; }
        }
      }
      reCache[p] = re;
      return re;
    }
    function anyMatch(list, u) {
      for (var i = 0; i < (list || []).length; i++) {
        var r = patToRe(list[i]);
        if (r && r.test(u)) return true;
      }
      return false;
    }

    function whenRoot(fn) {
      if (document.documentElement) { fn(); return; }
      var mo = new MutationObserver(function () {
        if (document.documentElement) { mo.disconnect(); fn(); }
      });
      mo.observe(document, { childList: true });
    }
    function addLink(href) {
      var l = document.createElement('link');
      l.rel = 'stylesheet'; l.href = href;
      (document.head || document.documentElement).appendChild(l);
    }
    function addScript(src) {
      var s = document.createElement('script');
      s.async = false; s.src = src;
      s.onload = s.onerror = function () { try { s.remove(); } catch (e) {} };
      (document.head || document.documentElement).appendChild(s);
    }
    function schedule(runAt, fn) {
      if (runAt === 'document_start') { whenRoot(fn); return; }
      if (runAt === 'document_end') {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn, { once: true });
        return;
      }
      if (document.readyState === 'complete') fn();
      else if (document.readyState === 'interactive') setTimeout(fn, 0);
      else document.addEventListener('DOMContentLoaded', function () { setTimeout(fn, 0); }, { once: true });
    }

    var url = location.href.split('#')[0];
    var isTop = (window.top === window);
    reg.forEach(function (en) {
      if (!isTop && !en.f) return;
      if (!anyMatch(en.m, url)) return;
      if (en.e && en.e.length && anyMatch(en.e, url)) return;
      getCtx(en.x);
      var base = ORIGIN + '/__dm_ext__/' + en.x;
      schedule(en.r, function () {
        if (en.c) addLink(base + '/__css/' + en.i + '.css');
        if (en.j) addScript(base + '/__cs/' + en.i + '.js');
      });
    });
  }
})();
