package com.dragon.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String HOME = "file:///android_asset/home.html";
    static final String EXT_HOST = "dm.ext";
    private static final int REQ_FILE = 11;
    private static final int REQ_ZIP = 12;
    private static final int REQ_PERM = 13;

    // ------------------------------------------------------------------ state
    Ext ext;
    volatile int curId;
    volatile String curUrl = "";
    volatile String curTitle = "";

    private SharedPreferences prefs;
    private boolean desktop;
    private boolean adblock;
    private boolean savehist;
    private boolean docStart;
    private String mobileUA;
    private String desktopUA;

    private FrameLayout rootFrame;
    private FrameLayout content;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView tabCount;

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private Tab cur;
    private int tabSeq = 0;

    private final Map<WebView, ScriptHandler> handles = new HashMap<>();
    private final Map<String, BgPage> bgs = new HashMap<>();
    private final ArrayList<WebView> popupViews = new ArrayList<>();
    private final Map<Integer, Pending> pending = new HashMap<>();
    private int respSeq = 0;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;

    static final class Tab {
        int id;
        WebView wv;
        String title = "";
        String url = "";
        boolean privateMode = false;
    }

    static final class BgPage {
        String extId;
        WebView wv;
        boolean loaded;
        final ArrayList<Runnable> queue = new ArrayList<>();

        void post(Runnable r) {
            if (loaded) r.run();
            else queue.add(r);
        }
    }

    static final class Pending {
        final WeakReference<WebView> wv;
        final int cb;

        Pending(WebView w, int cb) {
            this.wv = new WeakReference<>(w);
            this.cb = cb;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", false);
        adblock = prefs.getBoolean("adblock", true);
        savehist = prefs.getBoolean("savehist", true);
        ext = new Ext(this);

        String def = WebSettings.getDefaultUserAgent(this);
        mobileUA = def.replace("; wv", "").replace("Version/4.0 ", "");
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + ver + " Safari/537.36";

        boolean ds = false;
        try {
            ds = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        } catch (Throwable ignored) {
        }
        docStart = ds;

        buildUi();
        refreshExtensions();

        Uri data = getIntent() == null ? null : getIntent().getData();
        createTab(data != null ? data.toString() : HOME, null);
        if (b == null) getWindow().getDecorView().post(this::showSplash);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent == null ? null : intent.getData();
        if (data != null) createTab(data.toString(), null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            try {
                t.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        if (hasPrivateTabs()) CookieManager.getInstance().setAcceptCookie(true);
        for (BgPage bg : bgs.values()) {
            try {
                bg.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        if (cur != null && cur.wv.canGoBack()) {
            cur.wv.goBack();
            return;
        }
        if (tabs.size() > 1) {
            closeTab(cur);
            return;
        }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ UI

    private static final int RED = 0xFFE31B23;

    private UiKit.Ico navBack;
    private UiKit.Ico navFwd;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable roundBg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout cell(View inner, int sizeDp, View.OnClickListener l) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        c.addView(inner, new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        c.setOnClickListener(l);
        return c;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);
        getWindow().getDecorView().setSystemUiVisibility(0);

        rootFrame = new FrameLayout(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(0xFF000000);

        // top bar: [ G | search pill ] [messenger]
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(0xFF000000);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));

        LinearLayout pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(roundBg(0xFF181818, 0xFF3A1317, 22));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(22), dp(22));
        gp.leftMargin = dp(14);
        pill.addView(new UiKit.Ico(this, UiKit.B_GOOGLE, 0), gp);

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        urlBar.setHint("Search or type URL");
        urlBar.setHintTextColor(0xFF9A9A9A);
        urlBar.setTextColor(0xFFFFFFFF);
        urlBar.setBackground(null);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setPadding(dp(10), 0, dp(14), 0);
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(urlBar.getText().toString());
                urlBar.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        urlBar.setOnFocusChangeListener((v, has) -> {
            if (has) {
                urlBar.setText(cur != null && cur.url != null && !cur.url.startsWith("file:") ? cur.url : "");
                urlBar.selectAll();
            } else {
                refreshBar();
            }
        });
        pill.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        top.addView(pill, new LinearLayout.LayoutParams(0, dp(44), 1f));

        UiKit.Ico mess = new UiKit.Ico(this, UiKit.B_MESSENGER, 0);
        mess.setOnClickListener(v -> openMessenger());
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(40), dp(40));
        ml.leftMargin = dp(10);
        top.addView(mess, ml);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(RED));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF1A1A1A));
        progress.setVisibility(View.GONE);

        content = new FrameLayout(this);

        // bottom bar: back, forward, home, tabs, menu
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setBackgroundColor(0xFF0B0B0B);
        LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);

        navBack = new UiKit.Ico(this, UiKit.BACK, 0xFFFFFFFF);
        navFwd = new UiKit.Ico(this, UiKit.FORWARD, 0xFFFFFFFF);
        bottom.addView(cell(navBack, 26, v -> {
            if (cur != null && cur.wv.canGoBack()) cur.wv.goBack();
        }), cellLp);
        bottom.addView(cell(navFwd, 26, v -> {
            if (cur != null && cur.wv.canGoForward()) cur.wv.goForward();
        }), new LinearLayout.LayoutParams(cellLp));
        bottom.addView(cell(new UiKit.Ico(this, UiKit.HOME, RED), 28, v -> {
            if (cur != null) cur.wv.loadUrl(HOME);
        }), new LinearLayout.LayoutParams(cellLp));

        tabCount = new TextView(this);
        tabCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tabCount.setTextColor(0xFFFFFFFF);
        tabCount.setTypeface(Typeface.DEFAULT_BOLD);
        tabCount.setGravity(Gravity.CENTER);
        bottom.addView(cell(tabCount, 22, v -> showTabs()), new LinearLayout.LayoutParams(cellLp));
        bottom.addView(cell(new UiKit.Ico(this, UiKit.DOTS, 0xFFFFFFFF), 24, v -> showMenu()), new LinearLayout.LayoutParams(cellLp));

        View line = new View(this);
        line.setBackgroundColor(0xFF1C1C1C);

        main.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        main.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        main.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        main.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        main.addView(bottom, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        rootFrame.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootFrame);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String displayUrl(String u) {
        if (u == null) return "";
        String s = u;
        if (s.startsWith("https://")) s = s.substring(8);
        else if (s.startsWith("http://")) s = s.substring(7);
        if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void refreshBar() {
        boolean priv = cur != null && cur.privateMode;
        if (urlBar != null && !urlBar.hasFocus()) {
            urlBar.setText(cur == null || cur.url == null || cur.url.startsWith("file:") ? "" : displayUrl(cur.url));
        }
        if (urlBar != null) urlBar.setHint(priv ? "Incognito — search or type URL" : "Search or type URL");
        tabCount.setText(String.valueOf(tabs.size()));
        GradientDrawable box = new GradientDrawable();
        box.setStroke(dp(2), priv ? 0xFFB388FF : 0xFFFFFFFF);
        box.setCornerRadius(dp(6));
        tabCount.setBackground(box);
        if (navBack != null && cur != null) {
            navBack.setAlpha(cur.wv.canGoBack() ? 1f : 0.35f);
            navFwd.setAlpha(cur.wv.canGoForward() ? 1f : 0.35f);
        }
    }

    private void syncCur() {
        if (cur != null) {
            curId = cur.id;
            curUrl = cur.url == null ? "" : cur.url;
            curTitle = cur.title == null ? "" : cur.title;
        }
    }

    private void loadInput(String in) {
        String s = in == null ? "" : in.trim();
        if (s.length() == 0 || cur == null) return;
        String u;
        if (s.toLowerCase().startsWith("javascript:")) return;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            u = s;
        } else if (s.startsWith("localhost") || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            u = "http://" + s;
        } else if (!s.contains(" ") && s.contains(".") && !s.endsWith(".")) {
            u = "https://" + s;
        } else {
            u = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        cur.wv.loadUrl(u);
    }

    // ------------------------------------------------------------------ tabs

    Tab tabById(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    void openUrlInNewTab(final String url) {
        runOnUiThread(() -> {
            if (url != null && url.length() > 0) createTab(url, null);
        });
    }

    private Tab createTab(String url, WebView existing) {
        return createTab(url, existing, false);
    }

    private Tab createTab(String url, WebView existing, boolean privateMode) {
        Tab t = new Tab();
        t.id = ++tabSeq;
        t.privateMode = privateMode;
        t.wv = existing != null ? existing : new WebView(this);
        setupWebView(t);
        tabs.add(t);
        selectTab(t);
        if (existing == null && url != null) t.wv.loadUrl(url);
        return t;
    }

    private boolean hasPrivateTabs() {
        for (Tab tab : tabs) if (tab.privateMode) return true;
        return false;
    }

    private void restoreRegularCookiesIfNeeded() {
        if (!hasPrivateTabs()) {
            CookieManager manager = CookieManager.getInstance();
            manager.setAcceptCookie(true);
            for (Tab tab : tabs) manager.setAcceptThirdPartyCookies(tab.wv, true);
        }
    }

    private void selectTab(Tab t) {
        cur = t;
        content.removeAllViews();
        if (t.wv.getParent() instanceof ViewGroup) ((ViewGroup) t.wv.getParent()).removeView(t.wv);
        content.addView(t.wv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        progress.setVisibility(View.GONE);
        syncCur();
        if (urlBar != null && urlBar.hasFocus()) urlBar.clearFocus();
        refreshBar();
        t.wv.requestFocus();
    }

    private void closeTab(Tab t) {
        if (t == null) return;
        if (tabs.size() <= 1) {
            boolean wasPrivate = t.privateMode;
            t.privateMode = false;
            t.wv.clearCache(true);
            t.wv.clearHistory();
            t.wv.clearFormData();
            t.wv.loadUrl(HOME);
            if (wasPrivate) restoreRegularCookiesIfNeeded();
            return;
        }
        boolean wasPrivate = t.privateMode;
        int i = tabs.indexOf(t);
        tabs.remove(t);
        content.removeView(t.wv);
        dropHandle(t.wv);
        try {
            if (wasPrivate) {
                t.wv.clearCache(true);
                t.wv.clearHistory();
                t.wv.clearFormData();
            }
            t.wv.destroy();
        } catch (Exception ignored) {
        }
        if (wasPrivate) restoreRegularCookiesIfNeeded();
        if (cur == t) selectTab(tabs.get(Math.max(0, Math.min(i, tabs.size() - 1))));
        else refreshBar();
    }

    private void showTabs() {
        showPanel("tabs");
    }

    // ------------------------------------------------------------------ WebView setup

    private void applyUA(WebSettings s) {
        s.setUserAgentString(desktop ? desktopUA : mobileUA);
    }

    private void setupWebView(final Tab t) {
        final WebView w = t.wv;
        w.setBackgroundColor(Color.BLACK);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        if (t.privateMode) {
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setDomStorageEnabled(false);
            s.setDatabaseEnabled(false);
            s.setSaveFormData(false);
        }
        applyUA(s);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(!t.privateMode && !hasPrivateTabs());
        cm.setAcceptThirdPartyCookies(w, !t.privateMode && !hasPrivateTabs());

        Bridge br = new Bridge(this, "tab", t.id);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        w.addJavascriptInterface(new HomeActions(), "MahirHome");
        installBootstrap(w, ext.tabBootstrap());

        w.setWebViewClient(new TabClient(t));
        w.setWebChromeClient(new TabChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
    }

    private void startDownload(String url, String ua, String cd, String mime) {
        try {
            String fn = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("ডাউনলোড শুরু: " + fn);
        } catch (Exception e) {
            toast("ডাউনলোড করা গেল না");
        }
    }

    private void dropHandle(WebView w) {
        ScriptHandler h = handles.remove(w);
        if (h != null) {
            try {
                h.remove();
            } catch (Throwable ignored) {
            }
        }
    }

    private void installBootstrap(WebView w, String js) {
        dropHandle(w);
        if (!docStart) return;
        try {
            ScriptHandler h = WebViewCompat.addDocumentStartJavaScript(w, js, Collections.singleton("*"));
            handles.put(w, h);
        } catch (Throwable ignored) {
        }
    }

    private boolean handleExternal(String u) {
        if (u == null) return false;
        if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:")
                || u.startsWith("file:")) {
            return false;
        }
        try {
            Intent i;
            if (u.startsWith("intent:")) {
                i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            }
            startActivity(i);
        } catch (Exception e) {
            toast("এই লিংক খোলা গেল না");
        }
        return true;
    }

    private final class TabClient extends WebViewClient {
        private final Tab t;

        TabClient(Tab t) {
            this.t = t;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            if (x != null) return x;
            if (adblock && !r.isForMainFrame() && isAdHost(r.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleExternal(r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            if (url != null && url.startsWith("file:///android_asset/home.html")) {
                v.addJavascriptInterface(new HomeActions(), "MahirHome");
            } else {
                v.removeJavascriptInterface("MahirHome");
            }
            t.url = url;
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.tabBootstrap(), null);
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.url = url;
            if (!t.privateMode && savehist && url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                Store.add(prefs, "history", t.title, url, 300);
            }
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String page = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px 16px;color:#444'>"
                        + "<h2>পেজ লোড হয়নি</h2><p>ইন্টারনেট বা ঠিকানা চেক করে আবার চেষ্টা করুন।</p>"
                        + "<p style='color:#999;font-size:13px'>" + e.getDescription() + "</p></body></html>";
                String u = r.getUrl().toString();
                v.loadDataWithBaseURL(u, page, "text/html", "utf-8", u);
            }
        }
    }

    private final class TabChrome extends WebChromeClient {
        private final Tab t;

        TabChrome(Tab t) {
            this.t = t;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (t != cur) return;
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title == null ? "" : title;
            if (t == cur) syncCur();
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            WebView nw = new WebView(MainActivity.this);
            createTab(null, nw);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nw);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            for (Tab x : new ArrayList<>(tabs)) {
                if (x.wv == window) {
                    closeTab(x);
                    return;
                }
            }
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> handlePermission(req));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            rootFrame.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    // ------------------------------------------------------------------ camera / mic permission

    private void handlePermission(PermissionRequest req) {
        ArrayList<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            req.grant(req.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM || pendingPerm == null) return;
        PermissionRequest req = pendingPerm;
        pendingPerm = null;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) req.deny();
        else req.grant(ok.toArray(new String[0]));
    }

    // ------------------------------------------------------------------ menu

    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "google-analytics.com", "googletagservices.com", "adnxs.com", "criteo.com", "criteo.net",
            "taboola.com", "outbrain.com", "pubmatic.com", "rubiconproject.com", "openx.net",
            "adsterra.com", "popads.net", "propellerads.com", "mgid.com", "scorecardresearch.com",
            "adcolony.com", "applovin.com", "unityads.unity3d.com", "moatads.com", "amazon-adsystem.com"
    };

    private boolean isAdHost(String host) {
        if (host == null) return false;
        for (String h : AD_HOSTS) if (host.equals(h) || host.endsWith("." + h)) return true;
        return false;
    }

    // ------------------------------------------------------------------ in-app screens (panel.html)

    private Dialog panelDialog;
    private WebView panelWv;

    private void showMenu() {
        showPanel("menu");
    }

    private void showSavedList(String key, String title) {
        showPanel("bookmarks".equals(key) ? "bookmarks" : "history");
    }

    private void showSettings() {
        showPanel("settings");
    }

    private void openDownloads() {
        showPanel("downloads");
    }

    private void closePanel() {
        if (panelDialog != null) {
            try {
                panelDialog.dismiss();
            } catch (Exception ignored) {
            }
        }
    }

    private void showPanel(String route) {
        if (route == null || !route.matches("menu|tabs|downloads|bookmarks|history|extensions|settings|incognito|help|about|splash")) {
            route = "menu";
        }
        if (panelDialog != null && panelDialog.isShowing() && panelWv != null) {
            if (!"splash".equals(route)) panelWv.evaluateJavascript("window.__go&&window.__go('" + route + "')", null);
            return;
        }
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_NoActionBar);
        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        w.addJavascriptInterface(new PanelActions(), "MahirPanel");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // the panel never leaves its own local page
            }
        });
        d.setContentView(w);
        d.setOnKeyListener((dd, keyCode, ev) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (ev.getAction() == KeyEvent.ACTION_UP) w.evaluateJavascript("window.__back&&window.__back()", null);
                return true;
            }
            return false;
        });
        d.setOnDismissListener(x -> {
            if (panelDialog == d) {
                panelDialog = null;
                panelWv = null;
            }
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        panelDialog = d;
        panelWv = w;
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            d.getWindow().setStatusBarColor(Color.BLACK);
            d.getWindow().setNavigationBarColor(Color.BLACK);
        }
        w.loadUrl("file:///android_asset/panel.html#" + route);
    }

    private void showSplash() {
        showPanel("splash");
    }

    /** Methods the local panel page may call. Every method re-checks its own input. */
    private final class PanelActions {
        private DownloadManager dm() {
            return (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        }

        @android.webkit.JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("desktop", desktop);
                o.put("adblock", adblock);
                o.put("savehist", savehist);
                JSONArray tj = new JSONArray();
                for (Tab t : new ArrayList<>(tabs)) {
                    JSONObject x = new JSONObject();
                    x.put("id", t.id);
                    x.put("title", t.title);
                    x.put("url", t.url);
                    x.put("priv", t.privateMode);
                    x.put("cur", t == cur);
                    tj.put(x);
                }
                o.put("tabs", tj);
                o.put("bookmarks", Store.array(prefs, "bookmarks"));
                o.put("history", Store.array(prefs, "history"));
                JSONArray ej = new JSONArray();
                for (Ext.Info e : ext.list()) {
                    JSONObject x = new JSONObject();
                    x.put("id", e.id);
                    x.put("name", e.name);
                    x.put("version", e.version);
                    x.put("enabled", e.enabled);
                    x.put("popup", e.popupPath() != null);
                    ej.put(x);
                }
                o.put("exts", ej);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @android.webkit.JavascriptInterface
        public void close() {
            runOnUiThread(MainActivity.this::closePanel);
        }

        @android.webkit.JavascriptInterface
        public void go(final String u) {
            runOnUiThread(() -> {
                closePanel();
                if (u != null && u.matches("(?i)^https?://.*")) loadInput(u);
            });
        }

        @android.webkit.JavascriptInterface
        public void newTab() {
            runOnUiThread(() -> {
                closePanel();
                createTab(HOME, null);
            });
        }

        @android.webkit.JavascriptInterface
        public void newPrivate() {
            runOnUiThread(() -> {
                closePanel();
                createTab("https://www.google.com", null, true);
                toast("Incognito ট্যাব চালু • History, cache ও cookies বন্ধ");
            });
        }

        @android.webkit.JavascriptInterface
        public void messenger() {
            runOnUiThread(() -> {
                closePanel();
                openMessenger();
            });
        }

        @android.webkit.JavascriptInterface
        public void refresh() {
            runOnUiThread(() -> {
                closePanel();
                if (cur != null) cur.wv.reload();
            });
        }

        @android.webkit.JavascriptInterface
        public void share() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast("আগে একটি পেজ খুলুন");
                    return;
                }
                closePanel();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, cur.url);
                startActivity(Intent.createChooser(i, "Share page"));
            });
        }

        @android.webkit.JavascriptInterface
        public void copyLink() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast("আগে একটি পেজ খুলুন");
                    return;
                }
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("url", cur.url));
                toast("লিংক কপি হয়েছে");
            });
        }

        @android.webkit.JavascriptInterface
        public void exit() {
            runOnUiThread(() -> {
                closePanel();
                finish();
            });
        }

        @android.webkit.JavascriptInterface
        public void pickZip() {
            runOnUiThread(MainActivity.this::pickZip);
        }

        @android.webkit.JavascriptInterface
        public void toggle(final String key) {
            runOnUiThread(() -> {
                if ("desktop".equals(key)) {
                    toggleDesktop();
                } else if ("adblock".equals(key)) {
                    adblock = !adblock;
                    prefs.edit().putBoolean("adblock", adblock).apply();
                    if (cur != null) cur.wv.reload();
                } else if ("savehist".equals(key)) {
                    savehist = !savehist;
                    prefs.edit().putBoolean("savehist", savehist).apply();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public String addBookmark() {
            String u = curUrl;
            if (u == null || !u.matches("(?i)^https?://.*")) return "no";
            if (Store.has(prefs, "bookmarks", u)) return "dup";
            Store.add(prefs, "bookmarks", curTitle, u, 500);
            return "ok";
        }

        @android.webkit.JavascriptInterface
        public void delBookmark(int i) {
            Store.remove(prefs, "bookmarks", i);
        }

        @android.webkit.JavascriptInterface
        public void clearHistory() {
            Store.clear(prefs, "history");
        }

        @android.webkit.JavascriptInterface
        public void clearData() {
            runOnUiThread(() -> {
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                for (Tab t : tabs) t.wv.clearCache(true);
            });
        }

        @android.webkit.JavascriptInterface
        public void extToggle(final String id) {
            runOnUiThread(() -> {
                for (Ext.Info e : ext.list()) {
                    if (e.id.equals(id)) {
                        ext.setEnabled(e.id, !e.enabled);
                        break;
                    }
                }
                onExtensionsChanged();
            });
        }

        @android.webkit.JavascriptInterface
        public void extDelete(final String id) {
            runOnUiThread(() -> {
                ext.delete(id);
                onExtensionsChanged();
                toast("মুছে ফেলা হয়েছে");
            });
        }

        @android.webkit.JavascriptInterface
        public void extPopup(final String id) {
            runOnUiThread(() -> {
                for (Ext.Info e : ext.list()) {
                    if (e.id.equals(id)) {
                        closePanel();
                        openPopup(e);
                        return;
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void switchTab(final int id) {
            runOnUiThread(() -> {
                closePanel();
                Tab t = tabById(id);
                if (t != null) selectTab(t);
            });
        }

        @android.webkit.JavascriptInterface
        public void closeTab(final int id) {
            runOnUiThread(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.closeTab(t);
            });
        }

        @android.webkit.JavascriptInterface
        public String downloads() {
            JSONArray a = new JSONArray();
            Cursor c = null;
            try {
                c = dm().query(new DownloadManager.Query()
                        .orderBy(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP, DownloadManager.Query.ORDER_DESCENDING));
                while (c != null && c.moveToNext() && a.length() < 200) {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                    String name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    o.put("name", name == null ? "file" : name);
                    o.put("size", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                    o.put("done", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                    o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                    String mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                    o.put("mime", mime == null ? "" : mime);
                    o.put("time", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                    a.put(o);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return a.toString();
        }

        @android.webkit.JavascriptInterface
        public void openDownload(final String id) {
            runOnUiThread(() -> {
                try {
                    long l = Long.parseLong(id);
                    Uri u = dm().getUriForDownloadedFile(l);
                    if (u == null) {
                        toast("ফাইলটি খোলা যাচ্ছে না");
                        return;
                    }
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, dm().getMimeTypeForDownloadedFile(l));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    toast("ফাইলটি খোলা যাচ্ছে না");
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void deleteDownload(String id) {
            try {
                dm().remove(Long.parseLong(id));
            } catch (Exception ignored) {
            }
        }

        @android.webkit.JavascriptInterface
        public void clearDownloads() {
            Cursor c = null;
            try {
                c = dm().query(new DownloadManager.Query());
                ArrayList<Long> ids = new ArrayList<>();
                while (c != null && c.moveToNext()) ids.add(c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                for (long id : ids) dm().remove(id);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
        }
    }

    private final class HomeActions {
        @android.webkit.JavascriptInterface public void openUrl(String u){runOnUiThread(()->loadInput(u));}
        @android.webkit.JavascriptInterface public void showMenu(){runOnUiThread(()->MainActivity.this.showMenu());}
        @android.webkit.JavascriptInterface public void openMessenger(){runOnUiThread(()->MainActivity.this.openMessenger());}
        @android.webkit.JavascriptInterface public void toggleDesktop(){runOnUiThread(()->MainActivity.this.toggleDesktop());}
        @android.webkit.JavascriptInterface public void panel(String r){runOnUiThread(()->MainActivity.this.showPanel(r));}
    }

    private void openMessenger() {
        try {
            Intent app = getPackageManager().getLaunchIntentForPackage("com.facebook.orca");
            if (app != null) {
                startActivity(app);
            } else {
                createTab("https://www.messenger.com", null);
            }
        } catch (Exception e) {
            createTab("https://www.messenger.com", null);
        }
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        for (Tab t : tabs) applyUA(t.wv.getSettings());
        if (cur != null) cur.wv.reload();
        toast(desktop ? "ডেস্কটপ মোড চালু" : "ডেস্কটপ মোড বন্ধ");
    }

    private void confirmClear() {
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
                .setMessage("সব ক্যাশ, কুকি আর লগইন মুছে যাবে। ঠিক আছে?")
                .setPositiveButton("মুছুন", (d, w) -> {
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) t.wv.clearCache(true);
                    toast("মুছে ফেলা হয়েছে");
                })
                .setNegativeButton("না", null)
                .show();
    }

    // ------------------------------------------------------------------ extensions UI

    private void showExtensions() {
        showPanel("extensions");
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_ZIP);
        } catch (Exception e) {
            toast("ফাইল পিকার খোলা গেল না");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_ZIP) {
            if (res == RESULT_OK && data != null && data.getData() != null) installZip(data.getData());
        }
    }

    private void installZip(final Uri uri) {
        toast("এক্সটেনশন যোগ হচ্ছে...");
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("ফাইল পড়া যায়নি");
                final Ext.Info info;
                try {
                    info = ext.install(in);
                } finally {
                    in.close();
                }
                runOnUiThread(() -> {
                    toast("যোগ হয়েছে: " + (info == null ? "" : info.name));
                    onExtensionsChanged();
                    if (cur != null) cur.wv.reload();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast("জিপ কাজ করেনি: " + e.getMessage()));
            }
        }).start();
    }

    private void onExtensionsChanged() {
        refreshExtensions();
        if (panelWv != null) panelWv.evaluateJavascript("window.__refresh&&window.__refresh()", null);
    }

    /** Rebuilds background pages and re-registers the content-script bootstrap in every tab. */
    private void refreshExtensions() {
        for (BgPage b : bgs.values()) {
            rootFrame.removeView(b.wv);
            dropHandle(b.wv);
            try {
                b.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        bgs.clear();
        for (Ext.Info i : ext.list()) {
            if (i.enabled && i.hasBackground()) createBg(i);
        }
        String js = ext.tabBootstrap();
        for (Tab t : tabs) installBootstrap(t.wv, js);
    }

    // ------------------------------------------------------------------ extension pages (background / popup)

    private void configureExtWebView(WebView w, String kind, String extId) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        Bridge br = new Bridge(this, kind, 0);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.pageBootstrap(extId));
    }

    private final class ExtPageClient extends WebViewClient {
        private final String extId;
        private final Runnable onFinish;

        ExtPageClient(String extId, Runnable onFinish) {
            this.extId = extId;
            this.onFinish = onFinish;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap f) {
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.pageBootstrap(extId), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (onFinish != null) onFinish.run();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (EXT_HOST.equals(r.getUrl().getHost())) return false;
            openUrlInNewTab(r.getUrl().toString());
            return true;
        }
    }

    private void createBg(Ext.Info i) {
        final BgPage b = new BgPage();
        b.extId = i.id;
        b.wv = new WebView(this);
        configureExtWebView(b.wv, "bg", i.id);
        b.wv.setWebViewClient(new ExtPageClient(i.id, () -> {
            if (!b.loaded) {
                b.loaded = true;
                ArrayList<Runnable> q = new ArrayList<>(b.queue);
                b.queue.clear();
                for (Runnable r : q) r.run();
            }
        }));
        b.wv.setAlpha(0f);
        rootFrame.addView(b.wv, new FrameLayout.LayoutParams(1, 1));
        bgs.put(i.id, b);
        b.wv.loadUrl("https://" + EXT_HOST + Ext.PREFIX + i.id + "/_bg.html");
    }

    private void openPopup(Ext.Info e) {
        String p = e.popupPath();
        if (p == null) {
            toast("এই এক্সটেনশনে পপআপ নেই");
            return;
        }
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("✕   " + e.name);
        title.setTextColor(0xFFFFD27A);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14), 0, dp(14), 0);
        title.setBackgroundColor(0xFF111111);
        title.setOnClickListener(v -> d.dismiss());

        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        configureExtWebView(w, "popup", e.id);
        w.setWebViewClient(new ExtPageClient(e.id, null));
        popupViews.add(w);

        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        box.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        d.setContentView(box);
        d.setOnDismissListener(x -> {
            popupViews.remove(w);
            dropHandle(w);
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        w.loadUrl("https://" + EXT_HOST + Ext.PREFIX + e.id + "/" + p);
    }

    // ------------------------------------------------------------------ message routing (called by Bridge)

    private String senderJson(Bridge from, String extId) {
        JSONObject s = new JSONObject();
        try {
            s.put("id", extId);
            if ("tab".equals(from.kindName())) {
                Tab t = tabById(from.tabIdValue());
                JSONObject tb = new JSONObject();
                tb.put("id", from.tabIdValue());
                tb.put("url", t == null || t.url == null ? "" : t.url);
                tb.put("title", t == null || t.title == null ? "" : t.title);
                s.put("tab", tb);
                s.put("frameId", 0);
                s.put("url", t == null || t.url == null ? "" : t.url);
            }
        } catch (JSONException ignored) {
        }
        return s.toString();
    }

    void route(final Bridge from, final String extId, final String target, final int destTab,
               final String msg, final int cbId) {
        runOnUiThread(() -> {
            final int rid = ++respSeq;
            pending.put(rid, new Pending(from.webView(), cbId));
            final String sender = senderJson(from, extId);
            if ("bg".equals(target)) {
                final BgPage b = bgs.get(extId);
                if (b == null) {
                    respond(rid, "null");
                    return;
                }
                b.post(() -> deliver(b.wv, extId, msg, sender, rid));
            } else {
                Tab t = tabById(destTab);
                if (t == null) {
                    respond(rid, "null");
                    return;
                }
                deliver(t.wv, extId, msg, sender, rid);
            }
        });
    }

    private void deliver(WebView dest, String extId, String msg, String sender, final int rid) {
        String js = "(window.__dmDeliver?(window.__dmDeliver(" + JSONObject.quote(extId) + ","
                + JSONObject.quote(msg == null ? "null" : msg) + "," + JSONObject.quote(sender) + "," + rid + "),1):0)";
        dest.evaluateJavascript(js, value -> {
            if (!"1".equals(value)) respond(rid, "null");
        });
    }

    void respond(final int rid, final String json) {
        runOnUiThread(() -> {
            Pending p = pending.remove(rid);
            if (p == null) return;
            WebView w = p.wv.get();
            if (w != null) {
                w.evaluateJavascript("window.__dmCb&&window.__dmCb(" + p.cb + ","
                        + JSONObject.quote(json == null ? "null" : json) + ")", null);
            }
        });
    }

    void broadcastChanges(final String extId, final String changesJson) {
        runOnUiThread(() -> {
            final String js = "window.__dmChanged&&window.__dmChanged(" + JSONObject.quote(extId) + ","
                    + JSONObject.quote(changesJson) + ",'local')";
            for (Tab t : tabs) t.wv.evaluateJavascript(js, null);
            for (final BgPage b : bgs.values()) b.post(() -> b.wv.evaluateJavascript(js, null));
            for (WebView w : new ArrayList<>(popupViews)) w.evaluateJavascript(js, null);
        });
    }
}
