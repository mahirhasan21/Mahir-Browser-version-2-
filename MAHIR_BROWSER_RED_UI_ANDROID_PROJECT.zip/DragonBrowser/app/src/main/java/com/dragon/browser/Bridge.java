package com.dragon.browser;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

/** Native object visible to JS as window.__DM (one per WebView, so the caller is known). */
final class Bridge {
    private final MainActivity act;
    private final String kind;   // "tab" | "popup" | "bg"
    private final int tabId;
    private WeakReference<WebView> view;

    Bridge(MainActivity act, String kind, int tabId) {
        this.act = act;
        this.kind = kind;
        this.tabId = tabId;
    }

    void attach(WebView w) {
        view = new WeakReference<>(w);
    }

    WebView webView() {
        return view == null ? null : view.get();
    }

    String kindName() {
        return kind;
    }

    int tabIdValue() {
        return tabId;
    }

    @JavascriptInterface
    public String kind() {
        return kind;
    }

    @JavascriptInterface
    public String manifest(String extId) {
        return act.ext.manifestJson(extId);
    }

    @JavascriptInterface
    public String i18n(String extId, String key) {
        return act.ext.i18n(extId, key);
    }

    @JavascriptInterface
    public String storageGet(String extId, String keysJson) {
        return act.ext.storageGet(extId, keysJson);
    }

    @JavascriptInterface
    public void storageSet(String extId, String objJson) {
        JSONObject ch = act.ext.storageSet(extId, objJson);
        if (ch.length() > 0) act.broadcastChanges(extId, ch.toString());
    }

    @JavascriptInterface
    public void storageRemove(String extId, String keysJson) {
        JSONObject ch = act.ext.storageRemove(extId, keysJson);
        if (ch.length() > 0) act.broadcastChanges(extId, ch.toString());
    }

    @JavascriptInterface
    public void storageClear(String extId) {
        JSONObject ch = act.ext.storageClear(extId);
        if (ch.length() > 0) act.broadcastChanges(extId, ch.toString());
    }

    @JavascriptInterface
    public void send(String extId, String target, int destTab, String msgJson, int cbId) {
        act.route(this, extId, target, destTab, msgJson, cbId);
    }

    @JavascriptInterface
    public void respond(int respId, String json) {
        act.respond(respId, json);
    }

    @JavascriptInterface
    public String tabsQuery() {
        JSONArray a = new JSONArray();
        try {
            JSONObject o = new JSONObject();
            o.put("id", act.curId);
            o.put("url", act.curUrl);
            o.put("title", act.curTitle);
            o.put("active", true);
            o.put("windowId", 1);
            o.put("index", 0);
            a.put(o);
        } catch (Exception ignored) {
        }
        return a.toString();
    }

    @JavascriptInterface
    public void tabsCreate(String url) {
        act.openUrlInNewTab(url);
    }
}
